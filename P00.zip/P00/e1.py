
from Seq0 import *

if __name__ == "__main__":
    seq_ping()

